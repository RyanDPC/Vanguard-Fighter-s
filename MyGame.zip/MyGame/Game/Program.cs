﻿using MyGame.Game;

using var game = new Game1();
game.Run();
