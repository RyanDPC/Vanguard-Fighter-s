using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using MonoGame.Extended.Tiled;
using System;
using System.Collections.Generic;

namespace MyGame.Models
{
    public class EnemyLibrary
    {
        private List<Enemy> _enemies;
        public Texture2D _enemyTexture { get; set; }
        private Random _random;

        public EnemyLibrary(Texture2D enemyTexture)
        {
            _enemies = new List<Enemy>();
            _enemyTexture = enemyTexture;
            _random = new Random();
        }

        // Ajouter un ennemi � une position donn�e
        public void AddEnemy(Vector2 position)
        {
            _enemies.Add(new Enemy(_enemyTexture, position));
        }

        // Mettre � jour tous les ennemis et g�rer leur mort
        public void UpdateEnemies(GameTime gameTime, Vector2 playerPosition, GraphicsDevice graphicsDevice, TiledMap map)
        {
            for (int i = 0; i < _enemies.Count; i++)
            {
                var enemy = _enemies[i];

                if (enemy.IsAlive)
                {
                    enemy.();
                }
                else
                {
                    // R�appara�tre un nouvel ennemi � une position al�atoire si l'ennemi est mort
                    _enemies.RemoveAt(i);
                    RespawnEnemy();
                }
            }
        }

        // Dessiner tous les ennemis
        public void Draw(SpriteBatch spriteBatch)
        {
            foreach (var enemy in _enemies)
            {
                if (enemy.IsAlive)
                {
                    enemy.Draw(spriteBatch);
                }
            }
        }

        // R�appara�tre un nouvel ennemi � une position al�atoire sur la carte
        private void RespawnEnemy()
        {
            Vector2 randomPosition = new Vector2(_random.Next(100, 800), _random.Next(100, 600)); // Position al�atoire
            AddEnemy(randomPosition);
        }
    }
}
