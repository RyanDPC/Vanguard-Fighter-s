using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;

namespace MyGame.Services
{
    public class InputManager
    {
        private KeyboardState _currentKeyState;
        private KeyboardState _previousKeyState;
        private bool _canJump = true; // Pour limiter le saut multiple trop rapide
        private float _jumpCooldown = 0.1f; // Temps avant de pouvoir sauter à nouveau
        private float _jumpTimer = 0f;
        public void Update(GameTime gameTime)
        {
            // Mise à jour des états des touches
            _previousKeyState = _currentKeyState;
            _currentKeyState = Keyboard.GetState();

            // Gestion du cooldown pour le saut
            if (!_canJump)
            {
                _jumpTimer -= (float)gameTime.ElapsedGameTime.TotalSeconds;
                if (_jumpTimer <= 0)
                {
                    _canJump = true;
                }
            }
            _currentKeyState = Keyboard.GetState();
        }

        public Vector2 GetMovement()
        {
            Vector2 movement = Vector2.Zero;
            if (_currentKeyState.IsKeyDown(Keys.W)) movement.Y -= 1;
            if (_currentKeyState.IsKeyDown(Keys.S)) movement.Y += 1;
            if (_currentKeyState.IsKeyDown(Keys.A)) movement.X -= 1;
            if (_currentKeyState.IsKeyDown(Keys.D)) movement.X += 1;
            return movement;
        }

        public bool IsJumpPressed()
        {
            if (_canJump && _currentKeyState.IsKeyDown(Keys.Space) && _previousKeyState.IsKeyUp(Keys.Space))
            {
                _canJump = false; // Désactive la possibilité de sauter immédiatement après un saut
                _jumpTimer = _jumpCooldown; // Réinitialise le cooldown
                return true;
            }
            return false;
        }

        public bool IsShootPressed()
        {
            return Mouse.GetState().LeftButton == ButtonState.Pressed;
        }

        public bool IsReloadPressed()
        {
            return _currentKeyState.IsKeyDown(Keys.R);
        }

        public bool IsWeaponSwitchPressed(int weaponNumber)
        {
            switch (weaponNumber)
            {
                case 1: return _currentKeyState.IsKeyDown(Keys.D1);
                case 2: return _currentKeyState.IsKeyDown(Keys.D2);
                default: return false;
            }
        }

        public bool IsEscapePressed()
        {
            return _currentKeyState.IsKeyDown(Keys.F11) && _previousKeyState.IsKeyUp(Keys.F11);
        }
     
    }
}
