﻿using var game = new Vanguard_Fighters.Game1();
game.Run();
