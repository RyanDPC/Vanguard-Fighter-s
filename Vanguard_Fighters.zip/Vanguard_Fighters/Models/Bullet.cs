﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace MyGame.Models
{
    public class Bullet
    {
        public Rectangle Bounds { get; private set; }
        public Vector2 Position { get; private set; }
        public Vector2 Velocity { get; private set; }
        public int Damage { get; private set; }
        private int width = 10; // Largeur du rectangle
        private int height = 5; // Hauteur du rectangle

        public Bullet(Vector2 position, Vector2 velocity, int damage)
        {
            Position = position;
            Velocity = velocity;
            Damage = damage;
            Bounds = new Rectangle((int)position.X, (int)position.Y, width, height);
        }

        public void Update(GameTime gameTime)
        {
            Position += Velocity * (float)gameTime.ElapsedGameTime.TotalSeconds;
            Bounds = new Rectangle((int)Position.X, (int)Position.Y, width, height);
        }

        public void Draw(SpriteBatch spriteBatch, Color color)
        {
            // Crée un rectangle sans texture en utilisant la couleur fournie
            Texture2D rectTexture = new Texture2D(spriteBatch.GraphicsDevice, 1, 1);
            rectTexture.SetData(new[] { Color.White });
            spriteBatch.Draw(rectTexture, Bounds, color);
            rectTexture.Dispose(); // Supprimer la texture pour éviter les fuites de mémoire
        }

        public bool IsOffScreen(int screenWidth, int screenHeight)
        {
            return Position.X < 0 || Position.X > screenWidth || Position.Y < 0 || Position.Y > screenHeight;
        }
    }
}
