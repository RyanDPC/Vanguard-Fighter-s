﻿using System;
using MyGame.Library;
using MyGame.View;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace MyGame.Models
{
    public class Weapon
    {
        public WeaponStats Stats { get; private set; } // Stocke les caractéristiques de l'arme
        public Texture2D WeaponTexture { get; private set; } // Texture de l'arme
        public List<Bullet> Bullets { get; private set; } // Liste des projectiles

        private float timeSinceLastShot; // Temps écoulé depuis le dernier tir
        private float reloadTimer; // Timer pour le rechargement
        private bool isReloading; // Indique si l'arme est en train de recharger

        public Weapon(WeaponStats stats, Texture2D texture)
        {
            Stats = stats;
            WeaponTexture = texture;
            Bullets = new List<Bullet>();
            timeSinceLastShot = Stats.FireCooldown;
            reloadTimer = Stats.ReloadTime;
            isReloading = false;
        }

        public void Update(GameTime gameTime)
        {
            float elapsedSeconds = (float)gameTime.ElapsedGameTime.TotalSeconds;

            // Gestion du rechargement
            if (isReloading)
            {
                reloadTimer += elapsedSeconds;
                if (reloadTimer >= Stats.ReloadTime)
                {
                    // Fin du rechargement : recharge le chargeur complet (ou les munitions restantes si insuffisantes)
                    int ammoToReload = Math.Min(Stats.ClipSize, Stats.MaxAmmo);
                    Stats.MaxAmmo += ammoToReload;
                    isReloading = false;
                    reloadTimer = 0;
                    Console.WriteLine($"{Stats.Name} is reloaded. Ammo: {Stats.MaxAmmo}");
                }
            }

            // Mise à jour du temps depuis le dernier tir
            timeSinceLastShot += elapsedSeconds;
        }

        public bool CanShoot()
        {
            // Vérifie si l'arme peut tirer : pas en rechargement, assez de munitions et cooldown respecté
            return !isReloading && Stats.MaxAmmo > 0 && timeSinceLastShot >= (1 / Stats.FireCooldown);
        }

        public void Shoot(Texture2D bulletTexture, Vector2 position, Vector2 direction)
        {
            if (CanShoot())
            {
                // Crée un projectile et l'ajoute à la liste
                Bullet bullet = new Bullet(bulletTexture, position, direction);
                Bullets.Add(bullet);

                // Réinitialise le cooldown du tir
                timeSinceLastShot = 0;

                // Diminue le nombre de munitions
                Stats.MaxAmmo--;

                Console.WriteLine($"{Stats.Name} shoots. Remaining ammo: {Stats.MaxAmmo}");
            }
            else if (Stats.MaxAmmo <= 0)
            {
                Console.WriteLine($"{Stats.Name} is out of ammo! Reload needed.");
            }
            else
            {
                Console.WriteLine($"{Stats.Name} cannot shoot yet. Cooldown in progress.");
            }
        }

        public void Reload()
        {
            // Lance le rechargement si l'arme n'est pas déjà en train de recharger et qu'il reste des munitions globales
            if (!isReloading && Stats.MaxAmmo < Stats.ClipSize)
            {
                isReloading = true;
                reloadTimer = 0;
                Console.WriteLine($"{Stats.Name} is reloading...");
            }
        }

        public void UpdateBullets(GameTime gameTime)
        {
            foreach (var bullet in Bullets)
            {
                bullet.Update(gameTime);
            }

            // Retire les balles hors écran
            Bullets.RemoveAll(b => b.IsOffScreen());
        }

        public void DrawBullets(SpriteBatch spriteBatch)
        {
            foreach (var bullet in Bullets)
            {
                bullet.Draw(spriteBatch);
            }
        }
    }
}
