﻿
using var game = new Vanguard.Game1();
game.Run();
